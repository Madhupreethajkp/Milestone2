package com.example.springmvc.service;

import java.sql.SQLException;
import java.util.List;

import com.example.springmvc.model.Sector;

public interface SectorService {
public Sector insertSector(Sector sector);
public List<Sector> getSector() throws SQLException;

}
