package com.example.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springmvc.model.IPODetail;
import com.example.springmvc.service.IPOPlannedService;
@Controller
public class IPOPlannedControllerImpl implements IPOPlannedController {
@Autowired
private IPOPlannedService ipoPlannedService;


	@Override
	@RequestMapping(value="/addIPODetail")
	public String insertIPODetail(@ModelAttribute("a1") @Validated IPODetail ipoDetail,HttpServletRequest request,HttpServletResponse response)throws SQLException {
		System.out.println("inside controller");
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("companyName"));
	    System.out.println(ipoDetail.getCompanyName());
		ipoPlannedService.insertIPODetail(ipoDetail);
		return "addIPO";
	}

	@Override
	public List<IPODetail> getIPODetais() throws SQLException {
		// TODO Auto-generated method stub
		
		return ipoPlannedService.getIPODetais();
	}

	@Override
	public String insertIPODetail(IPODetail ipoDetail) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

@Override
@RequestMapping(value="/displayIPO")
public String display() {
	return "displayIPO";
}
	
}
