package com.example.springmvc.service;

import java.sql.SQLException;
import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springmvc.dao.UserDao;
import com.example.springmvc.model.User;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
private UserDao userDao;
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
@Override
public List<User> getUserList() throws SQLException {
	// TODO Auto-generated method stub
	return userDao.getUserList();
}

@Override
public void insertUser(User user) {
	System.out.println("Inside service");
	System.out.println(user.getUserName());
	userDao.insertUser(user);
}
@Override
public int validateUser(User u) throws Exception {
	// TODO Auto-generated method stub
	System.out.println("inside user service");
	int i=userDao.validateUser(u);
	return i;
	
}

}
