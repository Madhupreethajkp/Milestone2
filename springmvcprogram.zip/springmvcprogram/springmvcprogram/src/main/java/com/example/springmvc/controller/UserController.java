package com.example.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.springmvc.model.User;

public interface UserController {
	 public String insertUser(User user) throws SQLException;
	    public User updateUser(User user);
		public List<User> getUserList() throws Exception;

}
