package com.example.springmvc.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springmvc.model.Company;
import com.example.springmvc.service.CompanyService;
@Controller
public class CompanyControllerImpl implements CompanyController {
@Autowired
private CompanyService companyService;

//private static final Logger log=Logger.getLogger(CompanyControllerImpl.class);
@RequestMapping(value="/indexPage")
	public String indexPage() {
	return "index";
}
@RequestMapping(value="/logout")
public String logOut() {
	return "index";
}
@RequestMapping(value="/import")
public String importData() {
return "importData";
}
@RequestMapping(value="/manageCompany")
public String manageCompany() {
return "manageCompany";
}
@RequestMapping(value="/manageExchange")
public String manageExchange() {
return "manageExchange";
}
@RequestMapping(value="/addIPO")
public String addIpo() {
return "addIPO";
}
@RequestMapping(value="/createCompany")
public String companyForm() {
return "companyForm";
}
@RequestMapping(value="/update")
public String update() {
return "updateCompany";
}
@RequestMapping(value="/adminLogin",method=RequestMethod.GET)
public String adminLogin()
{
	return "adminLogin";
}

@RequestMapping(value="/adminLanding",method=RequestMethod.GET)
public String adminLanding()
{
	return "adminLandingPage";
}

@Override
@RequestMapping(value="/addCompany",method=RequestMethod.GET)
public String form(Company company,ModelMap model) {
	// TODO Auto-generated method stub
	model.addAttribute("e1",company);
	return "companyForm";
}


	@Override
	@RequestMapping(value="/addCompany",method=RequestMethod.POST)
	public String insertCompany(@ModelAttribute("e1") @Validated Company company) throws SQLException {
		// TODO Auto-generated method stub
		companyService.insertCompany(company);
		 return "companyForm";
			
	}

   /* @Override
	@RequestMapping(value="/editCompany")
	public Company updateCompany(Company company,HttpServletRequest request) {
		// TODO Auto-generated method stub
    	System.out.println(request.getParameter("companyName"));
		System.out.println("inside update controller");
		System.out.println(company.getCompanyName());
		return companyService.updateCompany(company);
		
	}*/

	@Override
	@RequestMapping(value="/updateCompany")
	public ModelAndView getCompanyList() throws Exception {
		// TODO Auto-generated method stub
		ModelAndView mv  = new ModelAndView();
		mv.setViewName("updateCompany");
		
		mv.addObject("updateCompany", companyService.getCompanyList());
		return mv;
			}
	@Override
	@RequestMapping(value="/compareCompany")
	public String compareCompany() {
		return "compareCompany";
	}
	@Override
	public Company updateCompany(Company company, HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}
	


	
	
		/*CompanyController companyController=new CompanyControllerImpl();
		
		try {
			System.out.println(companyController.getCompanyList());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	
	/*public static void main(String[] args) throws Exception {
			//SpringApplication.run(StockExchangeApplication.class, args);
			System.out.println("before the container");
			Company company=new Company();
			//company.setBoardOfDirectors("df");
			//company.setCompany_code(1001);
			ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml");
			System.out.println("after the container");
			CompanyController companyController=(CompanyController)applicationContext.getBean("companyControllerImpl");
		//	companyController.insertCompany(company);		
		 System.out.println(companyController.getCompanyList());
	}
*/
}
