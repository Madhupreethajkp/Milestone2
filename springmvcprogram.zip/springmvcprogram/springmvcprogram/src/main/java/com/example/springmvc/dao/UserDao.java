package com.example.springmvc.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springmvc.model.User;

public interface UserDao {
	public void insertUser(User user);
	public List<User> getUserList() throws SQLException;
	public int validateUser(User u) throws Exception;
	

}
