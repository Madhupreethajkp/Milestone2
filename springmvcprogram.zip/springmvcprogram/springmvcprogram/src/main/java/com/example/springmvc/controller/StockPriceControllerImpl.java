package com.example.springmvc.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.springmvc.model.StockPrice;
import com.example.springmvc.service.StockPriceService;
@Controller
public class StockPriceControllerImpl implements StockPriceController {
@Autowired
private StockPriceService stockPriceService;

	@Override
	public StockPrice updateStock(StockPrice stock) {
		// TODO Auto-generated method stub
		
		return null;
	}
	
	
	@Override
	@RequestMapping(value="/updateStock")
	public List<StockPrice> getStockPrice() throws SQLException {
		// TODO Auto-generated method stub
		ModelAndView mv=new ModelAndView();
		mv.setViewName("updateStock");
		return stockPriceService.getStockPrice();
	}

	@Override
	public StockPrice insertStock(StockPrice stock) {
		// TODO Auto-generated method stub
		stockPriceService.insertStock(stock);
		return null;
	}

}
