package com.example.springmvc.service;

import java.sql.SQLException;
import java.util.List;

import com.example.springmvc.model.StockExchange;

public interface StockExchangeService {
	public String insertStockExchange(StockExchange stockExchange);
	public List<StockExchange> getStockExchange() throws SQLException;

}
