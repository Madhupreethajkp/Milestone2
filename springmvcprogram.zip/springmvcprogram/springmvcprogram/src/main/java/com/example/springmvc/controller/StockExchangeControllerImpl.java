package com.example.springmvc.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springmvc.model.StockExchange;
import com.example.springmvc.service.StockExchangeService;
@Controller
public class StockExchangeControllerImpl implements StockExchangeController{
@Autowired
private StockExchangeService stockExchangeService;

@Override
@RequestMapping(value="/addStock",method=RequestMethod.GET)

public String stockForm(StockExchange stockExchange,ModelMap model) {
	model.addAttribute("s1", stockExchange);
	return "manageExhange";
}
@Override

@RequestMapping(value="/addStock")

	public String insertStockExchange(@ModelAttribute("s1")@Validated StockExchange stockExchange)throws SQLException {
		// TODO Auto-generated method stub
	stockExchangeService.insertStockExchange(stockExchange);
	System.out.println("inside controller");
	System.out.println(stockExchange.getStockexchange_name());
	return "manageExchange";
	}

	
	

@Override
@RequestMapping(value="/listStock")
public ModelAndView getStockExchange() throws SQLException{
	ModelAndView mv=new ModelAndView();
	mv.setViewName("listStock");
	mv.addObject("listStock", stockExchangeService.getStockExchange());
	return mv;
}
	

}
